#include <algorithm>
#include <cstring>
#include <cstdlib>

#include "dxvk_device.h"
#include "dxvk_memory.h"

namespace dxvk {
  
  DxvkMemory::DxvkMemory() { }
  DxvkMemory::DxvkMemory(
          DxvkMemoryAllocator*  alloc,
          DxvkMemoryChunk*      chunk,
          DxvkMemoryType*       type,
          VkDeviceMemory        memory,
          VkDeviceSize          offset,
          VkDeviceSize          length,
          void*                 mapPtr,
          bool                  shadowMap)
  : m_alloc   (alloc),
    m_chunk   (chunk),
    m_type    (type),
    m_memory  (memory),
    m_offset  (offset),
    m_length  (length),
    m_mapPtr  (mapPtr),
    m_shadowMap(shadowMap) { }
  
  
  DxvkMemory::DxvkMemory(DxvkMemory&& other)
  : m_alloc   (std::exchange(other.m_alloc,  nullptr)),
    m_chunk   (std::exchange(other.m_chunk,  nullptr)),
    m_type    (std::exchange(other.m_type,   nullptr)),
    m_memory  (std::exchange(other.m_memory, VkDeviceMemory(VK_NULL_HANDLE))),
    m_offset  (std::exchange(other.m_offset, 0)),
    m_length  (std::exchange(other.m_length, 0)),
    m_mapPtr  (std::exchange(other.m_mapPtr, nullptr)),
    m_shadowMap(std::exchange(other.m_shadowMap, false)) { }
  
  
  DxvkMemory& DxvkMemory::operator = (DxvkMemory&& other) {
    this->free();
    m_alloc   = std::exchange(other.m_alloc,  nullptr);
    m_chunk   = std::exchange(other.m_chunk,  nullptr);
    m_type    = std::exchange(other.m_type,   nullptr);
    m_memory  = std::exchange(other.m_memory, VkDeviceMemory(VK_NULL_HANDLE));
    m_offset  = std::exchange(other.m_offset, 0);
    m_length  = std::exchange(other.m_length, 0);
    m_mapPtr  = std::exchange(other.m_mapPtr, nullptr);
    m_shadowMap = std::exchange(other.m_shadowMap, false);
    return *this;
  }
  
  
  DxvkMemory::~DxvkMemory() {
    this->free();
  }
  
  
  void DxvkMemory::free() {
    if (m_alloc != nullptr)
      m_alloc->free(*this);
  }
  

  DxvkMemoryChunk::DxvkMemoryChunk(
          DxvkMemoryAllocator*  alloc,
          DxvkMemoryType*       type,
          DxvkDeviceMemory      memory,
          DxvkMemoryFlags       hints)
  : m_alloc(alloc), m_type(type), m_memory(memory), m_hints(hints) {
    // Mark the entire chunk as free
    m_freeList.push_back(FreeSlice { 0, memory.memSize });
  }
  
  
  DxvkMemoryChunk::~DxvkMemoryChunk() {
    // This call is technically not thread-safe, but it
    // doesn't need to be since we don't free chunks
    m_alloc->freeDeviceMemory(m_type, m_memory);
  }
  
  
  DxvkMemory DxvkMemoryChunk::alloc(
          VkMemoryPropertyFlags flags,
          VkDeviceSize          size,
          VkDeviceSize          align,
          DxvkMemoryFlags       hints) {
    // Property flags must be compatible. This could
    // be refined a bit in the future if necessary.
    if (m_memory.memFlags != flags || !checkHints(hints))
      return DxvkMemory();
    
    // If the chunk is full, return
    if (m_freeList.size() == 0)
      return DxvkMemory();
    
    // Select the slice to allocate from in a worst-fit
    // manner. This may help keep fragmentation low.
    auto bestSlice = m_freeList.begin();
    
    for (auto slice = m_freeList.begin(); slice != m_freeList.end(); slice++) {
      if (slice->length == size) {
        bestSlice = slice;
        break;
      } else if (slice->length > bestSlice->length) {
        bestSlice = slice;
      }
    }
    
    // We need to align the allocation to the requested alignment
    const VkDeviceSize sliceStart = bestSlice->offset;
    const VkDeviceSize sliceEnd   = bestSlice->offset + bestSlice->length;
    
    const VkDeviceSize allocStart = dxvk::align(sliceStart,        align);
    const VkDeviceSize allocEnd   = dxvk::align(allocStart + size, align);
    
    if (allocEnd > sliceEnd)
      return DxvkMemory();
    
    // We can use this slice, but we'll have to add
    // the unused parts of it back to the free list.
    m_freeList.erase(bestSlice);
    
    if (allocStart != sliceStart)
      m_freeList.push_back({ sliceStart, allocStart - sliceStart });
    
    if (allocEnd != sliceEnd)
      m_freeList.push_back({ allocEnd, sliceEnd - allocEnd });
    
    // Create the memory object with the aligned slice
    return DxvkMemory(m_alloc, this, m_type,
      m_memory.memHandle, allocStart, allocEnd - allocStart,
      reinterpret_cast<char*>(m_memory.memPointer) + allocStart,
      m_memory.memIsShadow);
  }
  
  
  void DxvkMemoryChunk::free(
          VkDeviceSize  offset,
          VkDeviceSize  length) {
    // Remove adjacent entries from the free list and then add
    // a new slice that covers all those entries. Without doing
    // so, the slice could not be reused for larger allocations.
    auto curr = m_freeList.begin();
    
    while (curr != m_freeList.end()) {
      if (curr->offset == offset + length) {
        length += curr->length;
        curr = m_freeList.erase(curr);
      } else if (curr->offset + curr->length == offset) {
        offset -= curr->length;
        length += curr->length;
        curr = m_freeList.erase(curr);
      } else {
        curr++;
      }
    }
    
    m_freeList.push_back({ offset, length });
  }
  
  
  bool DxvkMemoryChunk::isEmpty() const {
    return m_freeList.size() == 1
        && m_freeList[0].length == m_memory.memSize;
  }


  bool DxvkMemoryChunk::isCompatible(const Rc<DxvkMemoryChunk>& other) const {
    return other->m_memory.memFlags == m_memory.memFlags && other->m_hints == m_hints;
  }


  bool DxvkMemoryChunk::checkHints(DxvkMemoryFlags hints) const {
    DxvkMemoryFlags mask(
      DxvkMemoryFlag::Small,
      DxvkMemoryFlag::GpuReadable,
      DxvkMemoryFlag::GpuWritable,
      DxvkMemoryFlag::Transient);

    if (hints.test(DxvkMemoryFlag::IgnoreConstraints))
      mask = DxvkMemoryFlags();

    return (m_hints & mask) == (hints & mask);
  }


  DxvkMemoryAllocator::DxvkMemoryAllocator(const DxvkDevice* device)
  : m_vkd             (device->vkd()),
    m_device          (device),
    m_devProps        (device->adapter()->deviceProperties()),
    m_memProps        (device->adapter()->memoryProperties()) {
    for (uint32_t i = 0; i < m_memProps.memoryHeapCount; i++) {
      m_memHeaps[i].properties = m_memProps.memoryHeaps[i];
      m_memHeaps[i].stats      = DxvkMemoryStats { 0, 0 };
      m_memHeaps[i].budget     = 0;

      /* Target 80% of a heap on systems where we want
       * to avoid oversubscribing memory heaps */
      if ((m_memProps.memoryHeaps[i].flags & VK_MEMORY_HEAP_DEVICE_LOCAL_BIT)
       && (m_device->isUnifiedMemoryArchitecture()))
        m_memHeaps[i].budget = (8 * m_memProps.memoryHeaps[i].size) / 10;
    }
    
    for (uint32_t i = 0; i < m_memProps.memoryTypeCount; i++) {
      m_memTypes[i].heap       = &m_memHeaps[m_memProps.memoryTypes[i].heapIndex];
      m_memTypes[i].heapId     = m_memProps.memoryTypes[i].heapIndex;
      m_memTypes[i].memType    = m_memProps.memoryTypes[i];
      m_memTypes[i].memTypeId  = i;
    }

    /* Check what kind of heap the HVV memory type is on, if any. If the
     * HVV memory type is on the largest device-local heap, we either have
     * an UMA system or an RBAR-enabled system. Otherwise, there will likely
     * be a separate, smaller heap for it. */
    VkDeviceSize largestDeviceLocalHeap = 0;

    for (uint32_t i = 0; i < m_memProps.memoryTypeCount; i++) {
      if (m_memTypes[i].memType.propertyFlags & VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT)
        largestDeviceLocalHeap = std::max(largestDeviceLocalHeap, m_memTypes[i].heap->properties.size);
    }

    /* Work around an issue on Nvidia drivers where using the entire
     * device_local | host_visible heap can cause crashes or slowdowns */
    if (m_device->properties().core.properties.vendorID == uint16_t(DxvkGpuVendor::Nvidia)) {
      bool shrinkNvidiaHvvHeap = device->adapter()->matchesDriver(DxvkGpuVendor::Nvidia,
        VK_DRIVER_ID_NVIDIA_PROPRIETARY_KHR, 0, VK_MAKE_VERSION(465, 0, 0));

      applyTristate(shrinkNvidiaHvvHeap, device->config().shrinkNvidiaHvvHeap);

      if (shrinkNvidiaHvvHeap) {
        for (uint32_t i = 0; i < m_memProps.memoryTypeCount; i++) {
          VkMemoryPropertyFlags hvvFlags = VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT | VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT;

          if ((m_memTypes[i].memType.propertyFlags & hvvFlags) == hvvFlags
           && (m_memTypes[i].heap->properties.size < largestDeviceLocalHeap))
            m_memTypes[i].heap->budget = 32 << 20;
        }
      }
    }
  }
  
  
  DxvkMemoryAllocator::~DxvkMemoryAllocator() {
    
  }
  
  
  DxvkMemory DxvkMemoryAllocator::alloc(
    const VkMemoryRequirements*             req,
    const VkMemoryDedicatedRequirements&    dedAllocReq,
    const VkMemoryDedicatedAllocateInfo&    dedAllocInfo,
          VkMemoryPropertyFlags             flags,
          DxvkMemoryFlags                   hints) {
    std::lock_guard<dxvk::mutex> lock(m_mutex);

    // Keep small allocations together to avoid fragmenting
    // chunks for larger resources with lots of small gaps,
    // as well as resources with potentially weird lifetimes
    if (req->size <= SmallAllocationThreshold) {
      hints.set(DxvkMemoryFlag::Small);
      hints.clr(DxvkMemoryFlag::GpuWritable, DxvkMemoryFlag::GpuReadable);
    }

    // Ignore most hints for host-visible allocations since they
    // usually don't make much sense for those resources
    if (flags & VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT)
      hints = hints & DxvkMemoryFlag::Transient;

    // Try to allocate from a memory type which supports the given flags exactly
    auto dedAllocPtr = dedAllocReq.prefersDedicatedAllocation ? &dedAllocInfo : nullptr;

    // MALI/VORTEK FIX V4:
    // Hard-force the HOST_CACHED memory path for Vortek/Mali when DXVK asks
    // for HOST_VISIBLE|HOST_COHERENT memory. On the tested Mali-G57/Vortek
    // stack, memory type 0 reports DEVICE_LOCAL|HOST_VISIBLE|HOST_COHERENT
    // but vkMapMemory fails with VK_ERROR_MEMORY_MAP_FAILED. Memory type 1
    // reports DEVICE_LOCAL|HOST_VISIBLE|HOST_CACHED and is the only remaining
    // host-visible candidate in memoryTypeBits 0x3.
    //
    // Important: This intentionally does NOT fall back to HOST_COHERENT/type0
    // for the same request. If type1 still fails, the log will show V4 failure
    // and the next patch must use staging/copy instead of mapped memory.
    const bool maliVortek = std::strstr(m_devProps.deviceName, "Vortek") != nullptr
                         || std::strstr(m_devProps.deviceName, "Mali") != nullptr;

    DxvkMemory result;

    if (maliVortek
     && (flags & VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT)
     && (flags & VK_MEMORY_PROPERTY_HOST_COHERENT_BIT)) {
      VkMemoryPropertyFlags cachedFlags = (flags & ~VK_MEMORY_PROPERTY_HOST_COHERENT_BIT)
                                        | VK_MEMORY_PROPERTY_HOST_CACHED_BIT;

      Logger::warn(str::format(
        "DXVK-MALI-FIX-V4: forcing HOST_CACHED/type1 memory path",
        "\n  Device:    ", m_devProps.deviceName,
        "\n  Req size:  ", req->size,
        "\n  Req align: ", req->alignment,
        "\n  Old flags: 0x", std::hex, flags,
        "\n  New flags: 0x", std::hex, cachedFlags,
        "\n  Mem types: 0x", std::hex, req->memoryTypeBits));

      flags = cachedFlags;
    }

    result = this->tryAlloc(req, dedAllocPtr, flags, hints);

    // If the first attempt failed, try ignoring the dedicated allocation
    if (!result && dedAllocPtr && !dedAllocReq.requiresDedicatedAllocation) {
      result = this->tryAlloc(req, nullptr, flags, hints);
      dedAllocPtr = nullptr;
    }

    // Retry without the hint constraints
    if (!result) {
      hints.set(DxvkMemoryFlag::IgnoreConstraints);
      result = this->tryAlloc(req, nullptr, flags, hints);
    }

    // If that still didn't work, probe slower memory types as well
    VkMemoryPropertyFlags optFlags = VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT
                                   | VK_MEMORY_PROPERTY_HOST_CACHED_BIT;
    VkMemoryPropertyFlags remFlags = 0;
    
    while (!result && (flags & optFlags)) {
      remFlags |= optFlags & -optFlags;
      optFlags &= ~remFlags;

      result = this->tryAlloc(req, dedAllocPtr, flags & ~remFlags, hints);
    }
    
    // DXVK-MALI-FIX V7:
    // V6 proved that host-visible map failures can be bypassed with a CPU
    // shadow pointer, but NFS MW/D3D9 later hits tiny pure DEVICE_LOCAL
    // allocations (observed: 1536 bytes, flags 0x1, mem types 0x3) that the
    // Vortek/Mali stack still refuses through the normal allocator path.
    // Before failing, remap small DEVICE_LOCAL-only requests to the known
    // type1-compatible path: DEVICE_LOCAL|HOST_VISIBLE|HOST_CACHED. The
    // actual Vulkan memory is still allocated and can be bound to resources;
    // if vkMapMemory fails, the existing V6 shadow-map bridge lets DXVK
    // continue far enough to expose the next render/upload issue.
    if (!result
     && maliVortek
     && (flags & VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT)
     && !(flags & VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT)) {
      const VkDeviceSize smallDeviceLocalLimit = 1u << 20;

      if (req->size <= smallDeviceLocalLimit) {
        VkMemoryPropertyFlags fallbackFlags = VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT
                                            | VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT
                                            | VK_MEMORY_PROPERTY_HOST_CACHED_BIT;

        Logger::warn(str::format(
          "DXVK-MALI-FIX-V7: small DEVICE_LOCAL fallback",
          "\n  Device:    ", m_devProps.deviceName,
          "\n  Size:      ", req->size,
          "\n  Alignment: ", req->alignment,
          "\n  Old flags: 0x", std::hex, flags,
          "\n  New flags: 0x", std::hex, fallbackFlags,
          "\n  Mem types: 0x", std::hex, req->memoryTypeBits));

        DxvkMemoryFlags fallbackHints = hints;
        fallbackHints.set(DxvkMemoryFlag::IgnoreConstraints);

        result = this->tryAlloc(req, nullptr, fallbackFlags, fallbackHints);

        if (result) {
          Logger::warn(str::format(
            "DXVK-MALI-FIX-V7: accepted small DEVICE_LOCAL allocation with HOST_CACHED/type1 backing",
            "\n  Size: ", req->size));
        } else {
          Logger::warn(str::format(
            "DXVK-MALI-FIX-V7: small DEVICE_LOCAL fallback failed",
            "\n  Size: ", req->size));
        }
      } else {
        Logger::warn(str::format(
          "DXVK-MALI-FIX-V7: small DEVICE_LOCAL fallback skipped",
          "\n  Size:  ", req->size,
          "\n  Limit: ", smallDeviceLocalLimit));
      }
    }

    if (!result) {
      DxvkAdapterMemoryInfo memHeapInfo = m_device->adapter()->getMemoryHeapInfo();

      Logger::err(str::format(
        "DxvkMemoryAllocator: Memory allocation failed",
        "\n  Size:      ", req->size,
        "\n  Alignment: ", req->alignment,
        "\n  Mem flags: ", "0x", std::hex, flags,
        "\n  Mem types: ", "0x", std::hex, req->memoryTypeBits));

      for (uint32_t i = 0; i < m_memProps.memoryHeapCount; i++) {
        Logger::err(str::format("Heap ", i, ": ",
          (m_memHeaps[i].stats.memoryAllocated >> 20), " MB allocated, ",
          (m_memHeaps[i].stats.memoryUsed      >> 20), " MB used, ",
          m_device->extensions().extMemoryBudget
            ? str::format(
                (memHeapInfo.heaps[i].memoryAllocated >> 20), " MB allocated (driver), ",
                (memHeapInfo.heaps[i].memoryBudget    >> 20), " MB budget (driver), ",
                (m_memHeaps[i].properties.size        >> 20), " MB total")
            : str::format(
                (m_memHeaps[i].properties.size        >> 20), " MB total")));
      }

      throw DxvkError("DxvkMemoryAllocator: Memory allocation failed");
    }
    
    return result;
  }
  
  
  DxvkMemory DxvkMemoryAllocator::tryAlloc(
    const VkMemoryRequirements*             req,
    const VkMemoryDedicatedAllocateInfo*    dedAllocInfo,
          VkMemoryPropertyFlags             flags,
          DxvkMemoryFlags                   hints) {
    DxvkMemory result;

    for (uint32_t i = 0; i < m_memProps.memoryTypeCount && !result; i++) {
      const bool supported = (req->memoryTypeBits & (1u << i)) != 0;
      const bool adequate  = (m_memTypes[i].memType.propertyFlags & flags) == flags;
      
      if (supported && adequate) {
        result = this->tryAllocFromType(&m_memTypes[i],
          flags, req->size, req->alignment, hints, dedAllocInfo);
      }
    }
    
    return result;
  }
  
  
  DxvkMemory DxvkMemoryAllocator::tryAllocFromType(
          DxvkMemoryType*                   type,
          VkMemoryPropertyFlags             flags,
          VkDeviceSize                      size,
          VkDeviceSize                      align,
          DxvkMemoryFlags                   hints,
    const VkMemoryDedicatedAllocateInfo*    dedAllocInfo) {
    VkDeviceSize chunkSize = pickChunkSize(type->memTypeId, hints);

    DxvkMemory memory;

    // DXVK-MALI-FIX V3:
    // Vortek/Mali-G57 appears to reject vkMapMemory for pooled host-visible
    // chunks even when using an explicit map size. For host-visible allocations,
    // try an exact-size device memory allocation first so vkMapMemory maps only
    // the real resource size, not a suballocation chunk. This is especially
    // important for the observed D3D9 allocations around 3-5 KB failing after
    // chunk attempts of 32 KiB, 64 KiB, 128 KiB, etc.
    const bool maliVortekDirect = std::strstr(m_devProps.deviceName, "Vortek") != nullptr
                                || std::strstr(m_devProps.deviceName, "Mali") != nullptr;

    if (maliVortekDirect
     && (type->memType.propertyFlags & VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT)
     && size <= (1 << 20)) {
      Logger::warn(str::format(
        "DXVK-MALI-FIX-V4: trying exact-size HOST_CACHED/type1 allocation",
        "\n  Device:    ", m_devProps.deviceName,
        "\n  Mem type:  ", type->memTypeId,
        "\n  Type flags: 0x", std::hex, type->memType.propertyFlags,
        "\n  Req flags:  0x", std::hex, flags,
        "\n  Size:      ", std::dec, size,
        "\n  Align:     ", align));

      if (this->shouldFreeEmptyChunks(type->heap, size))
        this->freeEmptyChunks(type->heap);

      DxvkDeviceMemory devMem = this->tryAllocDeviceMemory(
        type, flags, size, hints, dedAllocInfo);

      if (devMem.memHandle != VK_NULL_HANDLE) {
        Logger::warn("DXVK-MALI-FIX-V4: exact-size HOST_CACHED/type1 allocation succeeded");
        memory = DxvkMemory(this, nullptr, type, devMem.memHandle, 0, devMem.memSize, devMem.memPointer, devMem.memIsShadow);
      } else {
        Logger::warn("DXVK-MALI-FIX-V4: exact-size HOST_CACHED/type1 allocation failed; falling back to chunk allocator");
      }
    }

    if (memory) {
      type->heap->stats.memoryUsed += memory.m_length;
      return memory;
    }

    if (size >= chunkSize || dedAllocInfo) {
      if (this->shouldFreeEmptyChunks(type->heap, size))
        this->freeEmptyChunks(type->heap);

      DxvkDeviceMemory devMem = this->tryAllocDeviceMemory(
        type, flags, size, hints, dedAllocInfo);

      if (devMem.memHandle != VK_NULL_HANDLE)
        memory = DxvkMemory(this, nullptr, type, devMem.memHandle, 0, devMem.memSize, devMem.memPointer, devMem.memIsShadow);
    } else {
      for (uint32_t i = 0; i < type->chunks.size() && !memory; i++)
        memory = type->chunks[i]->alloc(flags, size, align, hints);
      
      if (!memory) {
        DxvkDeviceMemory devMem;
        
        if (this->shouldFreeEmptyChunks(type->heap, chunkSize))
          this->freeEmptyChunks(type->heap);

        for (uint32_t i = 0; i < 6 && (chunkSize >> i) >= size && !devMem.memHandle; i++)
          devMem = tryAllocDeviceMemory(type, flags, chunkSize >> i, hints, nullptr);

        if (devMem.memHandle) {
          Rc<DxvkMemoryChunk> chunk = new DxvkMemoryChunk(this, type, devMem, hints);
          memory = chunk->alloc(flags, size, align, hints);

          type->chunks.push_back(std::move(chunk));
        }
      }
    }

    if (memory)
      type->heap->stats.memoryUsed += memory.m_length;

    return memory;
  }
  
  
  DxvkDeviceMemory DxvkMemoryAllocator::tryAllocDeviceMemory(
          DxvkMemoryType*                   type,
          VkMemoryPropertyFlags             flags,
          VkDeviceSize                      size,
          DxvkMemoryFlags                   hints,
    const VkMemoryDedicatedAllocateInfo*    dedAllocInfo) {
    bool useMemoryPriority = (flags & VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT)
                          && (m_device->features().extMemoryPriority.memoryPriority);
    
    if (type->heap->budget && type->heap->stats.memoryAllocated + size > type->heap->budget)
      return DxvkDeviceMemory();

    float priority = 0.0f;

    if (hints.test(DxvkMemoryFlag::GpuReadable))
      priority = 0.5f;
    if (hints.test(DxvkMemoryFlag::GpuWritable))
      priority = 1.0f;

    DxvkDeviceMemory result;
    result.memSize  = size;
    result.memFlags = flags;
    result.priority = priority;

    VkMemoryPriorityAllocateInfoEXT prio;
    prio.sType            = VK_STRUCTURE_TYPE_MEMORY_PRIORITY_ALLOCATE_INFO_EXT;
    prio.pNext            = dedAllocInfo;
    prio.priority         = priority;

    VkMemoryAllocateInfo info;
    info.sType            = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
    info.pNext            = useMemoryPriority ? &prio : prio.pNext;
    info.allocationSize   = size;
    info.memoryTypeIndex  = type->memTypeId;

    const bool maliVortekAlloc = std::strstr(m_devProps.deviceName, "Vortek") != nullptr
                              || std::strstr(m_devProps.deviceName, "Mali") != nullptr;

    VkResult allocStatus = m_vkd->vkAllocateMemory(m_vkd->device(), &info, nullptr, &result.memHandle);

    // DXVK-MALI-FIX V11:
    // V10 showed that the current crash can happen before map/bind: some tiny
    // HOST_VISIBLE|HOST_CACHED allocations fail directly in vkAllocateMemory
    // on Vortek/Mali (observed: size 12224, flags 0xa, memTypes 0x3). Retry
    // with rounded page/chunk-friendly sizes. If map still fails afterwards,
    // the existing V6 CPU-shadow path takes over.
    if (allocStatus != VK_SUCCESS
     && maliVortekAlloc
     && (flags & VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT)
     && (flags & VK_MEMORY_PROPERTY_HOST_CACHED_BIT)
     && size <= (8u << 20)) {
      Logger::warn(str::format(
        "DXVK-MALI-FIX-V11: vkAllocateMemory failed for HOST_CACHED/type1",
        "\n  Device:    ", m_devProps.deviceName,
        "\n  Mem type:  ", type->memTypeId,
        "\n  Flags:     0x", std::hex, flags,
        "\n  Size:      ", std::dec, size,
        "\n  Alloc:     ", info.allocationSize));

      const VkDeviceSize candidates[] = {
        dxvk::align(size, VkDeviceSize(4096)),
        dxvk::align(size, VkDeviceSize(16384)),
        dxvk::align(size, VkDeviceSize(65536)),
        dxvk::align(size, VkDeviceSize(262144)),
        dxvk::align(size, VkDeviceSize(1048576)),
      };

      VkDeviceSize lastCandidate = 0;

      for (VkDeviceSize candidate : candidates) {
        if (candidate <= size || candidate == lastCandidate || candidate > (8u << 20))
          continue;

        lastCandidate = candidate;
        info.allocationSize = candidate;

        Logger::warn(str::format(
          "DXVK-MALI-FIX-V11: retrying rounded HOST_CACHED/type1 allocation",
          "\n  Old size: ", size,
          "\n  New size: ", candidate));

        allocStatus = m_vkd->vkAllocateMemory(m_vkd->device(), &info, nullptr, &result.memHandle);

        if (allocStatus == VK_SUCCESS) {
          result.memSize = candidate;
          Logger::warn(str::format(
            "DXVK-MALI-FIX-V11: allocation failure bypass accepted",
            "\n  Rounded size: ", candidate));
          break;
        }
      }
    }

    if (allocStatus != VK_SUCCESS)
      return DxvkDeviceMemory();

    if (result.memSize < info.allocationSize)
      result.memSize = info.allocationSize;
    
    if (flags & VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT) {
      // DXVK-MALI-FIX V2:
      // Vortek on Mali-G57 reports host-visible memory types, but mapping with
      // VK_WHOLE_SIZE can fail even for tiny DXVK D3D9 allocations. Use the
      // explicit allocation size instead, and log the exact memory type used.
      // This targets the observed VK_ERROR_MEMORY_MAP_FAILED on Mem flags 0x6 /
      // Mem types 0x3 with small allocations around 4 KB.
      const bool maliVortek = std::strstr(m_devProps.deviceName, "Vortek") != nullptr
                           || std::strstr(m_devProps.deviceName, "Mali") != nullptr;

      VkDeviceSize mapSize = maliVortek ? result.memSize : VK_WHOLE_SIZE;

      if (maliVortek) {
        Logger::warn(str::format(
          "DXVK-MALI-FIX-V2: vkMapMemory explicit-size path",
          "\n  Device:    ", m_devProps.deviceName,
          "\n  Mem type:  ", type->memTypeId,
          "\n  Mem flags: 0x", std::hex, flags,
          "\n  Alloc:     ", std::dec, result.memSize,
          "\n  Map size:  ", mapSize));
      }

      VkResult status = m_vkd->vkMapMemory(m_vkd->device(), result.memHandle, 0, mapSize, 0, &result.memPointer);

      if (status != VK_SUCCESS) {
        Logger::err(str::format(
          "DxvkMemoryAllocator: Mapping memory failed with ", status,
          "\n  DXVK-MALI-FIX-V2: map failed",
          "\n  Device:    ", m_devProps.deviceName,
          "\n  Mem type:  ", type->memTypeId,
          "\n  Mem flags: 0x", std::hex, flags,
          "\n  Alloc:     ", std::dec, result.memSize,
          "\n  Map size:  ", mapSize));

        // DXVK-MALI-FIX V5:
        // Last-resort compatibility path for Vortek/Mali when vkMapMemory
        // fails on memory types that advertise HOST_VISIBLE. Instead of
        // failing device creation immediately, expose a shadow CPU pointer
        // for tiny host-visible allocations so DXVK can continue booting.
        //
        // WARNING: This is intentionally experimental. Data written to this
        // shadow pointer is not automatically synchronized to the Vulkan
        // allocation, so rendering may be black/corrupt. This patch is mainly
        // to test whether bypassing the fatal map error lets the app reach
        // later DXVK stages. If it advances, V6 must replace this with a real
        // staging/copy path.
        // DXVK-MALI-FIX V6:
        // V5 proved that the game advances when map failures are bypassed, but
        // real workloads immediately hit medium allocations as well (98 KiB,
        // 256 KiB, 483 KiB and even 4 MiB). Extend the CPU shadow fallback to
        // cover these allocations so the allocator can return success instead
        // of killing device creation. This still is not a final GPU upload path;
        // it is a compatibility bridge to locate the next failure stage.
        const VkDeviceSize shadowLimit = 8u << 20;

        if (maliVortek && result.memSize <= shadowLimit) {
          result.memPointer = std::calloc(1, size_t(result.memSize ? result.memSize : 1));

          if (result.memPointer != nullptr) {
            result.memIsShadow = true;
            Logger::warn(str::format(
              "DXVK-MALI-FIX-V6: shadow-map fallback malloc succeeded",
              "\n  Device:    ", m_devProps.deviceName,
              "\n  Mem type:  ", type->memTypeId,
              "\n  Mem flags: 0x", std::hex, flags,
              "\n  Alloc:     ", std::dec, result.memSize,
              "\n  Limit:     ", shadowLimit));
            Logger::warn("DXVK-MALI-FIX-V6: overriding vkMapMemory failure with CPU shadow pointer");
          } else {
            Logger::err("DXVK-MALI-FIX-V6: shadow-map fallback malloc failed");
            m_vkd->vkFreeMemory(m_vkd->device(), result.memHandle, nullptr);
            return DxvkDeviceMemory();
          }
        } else {
          Logger::err(str::format(
            "DXVK-MALI-FIX-V6: shadow-map fallback skipped",
            "\n  Alloc: ", result.memSize,
            "\n  Limit: ", shadowLimit));
          m_vkd->vkFreeMemory(m_vkd->device(), result.memHandle, nullptr);
          return DxvkDeviceMemory();
        }
      }

      if (maliVortek) {
        if (result.memIsShadow)
          Logger::warn("DXVK-MALI-FIX-V6: device memory accepted with CPU shadow pointer");
        else
          Logger::warn("DXVK-MALI-FIX-V2: vkMapMemory explicit-size path succeeded");
      }
    }

    type->heap->stats.memoryAllocated += result.memSize;
    m_device->adapter()->notifyHeapMemoryAlloc(type->heapId, result.memSize);
    return result;
  }


  void DxvkMemoryAllocator::free(
    const DxvkMemory&           memory) {
    std::lock_guard<dxvk::mutex> lock(m_mutex);
    memory.m_type->heap->stats.memoryUsed -= memory.m_length;

    if (memory.m_chunk != nullptr) {
      this->freeChunkMemory(
        memory.m_type,
        memory.m_chunk,
        memory.m_offset,
        memory.m_length);
    } else {
      DxvkDeviceMemory devMem;
      devMem.memHandle   = memory.m_memory;
      devMem.memPointer  = memory.m_shadowMap ? memory.m_mapPtr : nullptr;
      devMem.memSize     = memory.m_length;
      devMem.memIsShadow = memory.m_shadowMap;
      this->freeDeviceMemory(memory.m_type, devMem);
    }
  }

  
  void DxvkMemoryAllocator::freeChunkMemory(
          DxvkMemoryType*       type,
          DxvkMemoryChunk*      chunk,
          VkDeviceSize          offset,
          VkDeviceSize          length) {
    chunk->free(offset, length);

    if (chunk->isEmpty()) {
      Rc<DxvkMemoryChunk> chunkRef = chunk;

      // Free the chunk if we have to, or at least put it at the end of
      // the list so that chunks that are already in use and cannot be
      // freed are prioritized for allocations to reduce memory pressure.
      type->chunks.erase(std::remove(type->chunks.begin(), type->chunks.end(), chunkRef));

      if (!this->shouldFreeChunk(type, chunkRef))
        type->chunks.push_back(std::move(chunkRef));
    }
  }
  

  void DxvkMemoryAllocator::freeDeviceMemory(
          DxvkMemoryType*       type,
          DxvkDeviceMemory      memory) {
    if (memory.memIsShadow && memory.memPointer != nullptr) {
      Logger::warn(str::format(
        "DXVK-MALI-FIX-V6: freeing CPU shadow pointer",
        "\n  Size: ", memory.memSize));
      std::free(memory.memPointer);
      memory.memPointer = nullptr;
    }

    m_vkd->vkFreeMemory(m_vkd->device(), memory.memHandle, nullptr);
    type->heap->stats.memoryAllocated -= memory.memSize;
    m_device->adapter()->notifyHeapMemoryFree(type->heapId, memory.memSize);
  }


  VkDeviceSize DxvkMemoryAllocator::pickChunkSize(uint32_t memTypeId, DxvkMemoryFlags hints) const {
    VkMemoryType type = m_memProps.memoryTypes[memTypeId];
    VkMemoryHeap heap = m_memProps.memoryHeaps[type.heapIndex];

    // Default to a chunk size of 128 MiB
    VkDeviceSize chunkSize = 128 << 20;

    if (hints.test(DxvkMemoryFlag::Small))
      chunkSize = 16 << 20;

    // Try to waste a bit less system memory especially in
    // 32-bit applications due to address space constraints
    if (type.propertyFlags & VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT)
      chunkSize = (env::is32BitHostPlatform() ? 16 : 64) << 20;

    // DXVK-MALI-FIX V2:
    // On Vortek/Mali-G57, mapping large host-visible chunks may fail before
    // DXVK can suballocate tiny D3D9 buffers. Use very small chunks for small
    // host-visible allocations so the driver maps only what is needed.
    const bool maliVortek = std::strstr(m_devProps.deviceName, "Vortek") != nullptr
                         || std::strstr(m_devProps.deviceName, "Mali") != nullptr;

    if (maliVortek && (type.propertyFlags & VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT)) {
      if (hints.test(DxvkMemoryFlag::Small))
        chunkSize = 64 << 10;
      else if (env::is32BitHostPlatform())
        chunkSize = 1 << 20;
    }

    // Reduce the chunk size on small heaps so
    // we can at least fit in 15 allocations
    while (chunkSize * 15 > heap.size)
      chunkSize >>= 1;

    return chunkSize;
  }


  bool DxvkMemoryAllocator::shouldFreeChunk(
    const DxvkMemoryType*       type,
    const Rc<DxvkMemoryChunk>&  chunk) const {
    // Under memory pressure, we should start freeing everything.
    if (this->shouldFreeEmptyChunks(type->heap, 0))
      return true;

    // Even if we have enough memory to spare, only keep
    // one chunk of each type around to save memory.
    for (const auto& c : type->chunks) {
      if (c != chunk && c->isEmpty() && c->isCompatible(chunk))
        return true;
    }

    return false;
  }


  bool DxvkMemoryAllocator::shouldFreeEmptyChunks(
    const DxvkMemoryHeap*       heap,
          VkDeviceSize          allocationSize) const {
    VkDeviceSize budget = heap->budget;

    if (!budget)
      budget = (heap->properties.size * 4) / 5;

    return heap->stats.memoryAllocated + allocationSize > budget;
  }


  void DxvkMemoryAllocator::freeEmptyChunks(
    const DxvkMemoryHeap*       heap) {
    for (uint32_t i = 0; i < m_memProps.memoryTypeCount; i++) {
      DxvkMemoryType* type = &m_memTypes[i];

      if (type->heap != heap)
        continue;

      type->chunks.erase(
        std::remove_if(type->chunks.begin(), type->chunks.end(),
          [] (const Rc<DxvkMemoryChunk>& chunk) { return chunk->isEmpty(); }),
        type->chunks.end());
    }
  }

}
