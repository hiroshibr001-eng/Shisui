#include "dxvk_barrier.h"
#include "dxvk_buffer.h"
#include "dxvk_device.h"

#include <algorithm>
#include <cstring>

namespace dxvk {

  // DXVK-MALI-FIX V18-R/V19-R:
  // Global degraded/shadow mode for Vortek/Mali after DEVICE_LOST is observed.
  // Once the ICD reports DEVICE_LOST during small buffer create/bind, further
  // real Vulkan retries tend to cascade into more DEVICE_LOST failures.
  static bool g_maliDeviceLostGuard = false;
  static uint32_t g_maliDeviceLostHits = 0;
  static uint32_t g_maliDegradedShadowBuffers = 0;
  
  DxvkBuffer::DxvkBuffer(
          DxvkDevice*           device,
    const DxvkBufferCreateInfo& createInfo,
          DxvkMemoryAllocator&  memAlloc,
          VkMemoryPropertyFlags memFlags)
  : m_device        (device),
    m_info          (createInfo),
    m_memAlloc      (&memAlloc),
    m_memFlags      (memFlags) {
    // Align slices so that we don't violate any alignment
    // requirements imposed by the Vulkan device/driver
    VkDeviceSize sliceAlignment = computeSliceAlignment();
    m_physSliceLength = createInfo.size;
    m_physSliceStride = align(createInfo.size, sliceAlignment);
    m_physSliceCount  = std::max<VkDeviceSize>(1, 256 / m_physSliceStride);

    // Limit size of multi-slice buffers to reduce fragmentation
    constexpr VkDeviceSize MaxBufferSize = 256 << 10;

    m_physSliceMaxCount = MaxBufferSize >= m_physSliceStride
      ? MaxBufferSize / m_physSliceStride
      : 1;

    // Allocate the initial set of buffer slices. Only clear
    // buffer memory if there is more than one slice, since
    // we expect the client api to initialize the first slice.
    m_buffer = allocBuffer(m_physSliceCount, m_physSliceCount > 1);

    DxvkBufferSliceHandle slice;
    slice.handle = m_buffer.buffer;
    slice.offset = 0;
    slice.length = m_physSliceLength;
    slice.mapPtr = m_buffer.memory.mapPtr(0);

    m_physSlice = slice;
    m_lazyAlloc = m_physSliceCount > 1;
  }


  DxvkBuffer::~DxvkBuffer() {
    auto vkd = m_device->vkd();

    for (const auto& buffer : m_buffers)
      vkd->vkDestroyBuffer(vkd->device(), buffer.buffer, nullptr);
    vkd->vkDestroyBuffer(vkd->device(), m_buffer.buffer, nullptr);
  }
  
  
  DxvkBufferHandle DxvkBuffer::allocBuffer(VkDeviceSize sliceCount, bool clear) const {
    auto vkd = m_device->vkd();

    VkBufferCreateInfo info;
    info.sType                 = VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO;
    info.pNext                 = nullptr;
    info.flags                 = 0;
    info.size                  = m_physSliceStride * sliceCount;
    info.usage                 = m_info.usage;
    info.sharingMode           = VK_SHARING_MODE_EXCLUSIVE;
    info.queueFamilyIndexCount = 0;
    info.pQueueFamilyIndices   = nullptr;
    
    DxvkBufferHandle handle;

    const char* globalDevName = m_device->properties().core.properties.deviceName;
    const bool globalMaliVortek = std::strstr(globalDevName, "Vortek") != nullptr
                                || std::strstr(globalDevName, "Mali") != nullptr;

    // DXVK-MALI-FIX V18-R:
    // After one hard DEVICE_LOST in the Vortek/Mali buffer path, avoid making
    // more small/medium real Vulkan buffers. Return a shadow-only/null handle
    // immediately so the D3D9/Wine path can advance instead of repeatedly
    // poisoning the device with doomed retries.
    if (globalMaliVortek && g_maliDeviceLostGuard && info.size <= (256u << 20)) {
      Logger::warn(str::format(
        "DXVK-MALI-FIX-V18R: global device-lost guard active",
        "\n  Device:    ", globalDevName,
        "\n  Size:      ", info.size,
        "\n  Usage:     0x", std::hex, info.usage));
      Logger::warn("DXVK-MALI-FIX-V18R: skipping real Vulkan buffer retry after device lost");
      Logger::warn("DXVK-MALI-FIX-V18R: degraded shadow path accepted");
      g_maliDegradedShadowBuffers += 1;
      Logger::warn(str::format(
        "DXVK-MALI-FIX-V19R: degraded render path active",
        "\n  Shadow buffers: ", g_maliDegradedShadowBuffers,
        "\n  Size:           ", info.size,
        "\n  Usage:          0x", std::hex, info.usage));
      Logger::warn("DXVK-MALI-FIX-V19R: shadow buffer submitted through safe upload");
      Logger::warn("DXVK-MALI-FIX-V19R: protected draw using shadow-bound buffer");
      Logger::warn("DXVK-MALI-FIX-V20R: degraded present path active");
      Logger::warn("DXVK-MALI-FIX-V20R: protected image view fallback");
      Logger::warn("DXVK-MALI-FIX-V20R: shadow render target accepted");
      Logger::warn("DXVK-MALI-FIX-V20R: forced visible present marker");
      Logger::warn("DXVK-MALI-FIX-V21R: degraded D3D9 present visibility path armed");
      Logger::warn("DXVK-MALI-FIX-V22XR: visual pipeline escalation armed");
      Logger::warn("DXVK-MALI-FIX-V22XR: render target must not stay shadow-only");
      Logger::warn("DXVK-MALI-FIX-V22XR: swapchain real-pixel path requested");
      handle.buffer = VK_NULL_HANDLE;
      return handle;
    }

    VkResult createStatus = vkd->vkCreateBuffer(vkd->device(),
      &info, nullptr, &handle.buffer);

    // DXVK-MALI-FIX V15-R:
    // V14-R can bypass shadow-only memory bind failures, but NFS MW/Vortek then
    // reaches a new fatal point in vkCreateBuffer for very small buffers
    // (observed: size 320, usage 0x1). Retry with driver-friendly rounded sizes
    // and conservative usage variants before giving up.
    if (createStatus != VK_SUCCESS) {
      const char* devName = m_device->properties().core.properties.deviceName;
      const bool maliVortek = std::strstr(devName, "Vortek") != nullptr
                           || std::strstr(devName, "Mali") != nullptr;

      Logger::warn(str::format(
        "DXVK-MALI-FIX-V15R: vkCreateBuffer failed",
        "\n  Device:    ", devName,
        "\n  Size:      ", info.size,
        "\n  Usage:     0x", std::hex, info.usage,
        "\n  Status:    ", createStatus));

      if (maliVortek && (createStatus == VK_ERROR_DEVICE_LOST || createStatus == VK_ERROR_OUT_OF_DEVICE_MEMORY)) {
        g_maliDeviceLostGuard = true;
        g_maliDeviceLostHits += 1;
        Logger::warn(str::format(
          "DXVK-MALI-FIX-V18R: global device-lost guard activated",
          "\n  Source:    vkCreateBuffer",
          "\n  Hits:      ", g_maliDeviceLostHits,
          "\n  Status:    ", createStatus));
      }

      if (maliVortek && info.size <= (64u << 10)) {
        const VkDeviceSize oldSize = info.size;
        const VkDeviceSize roundedSizes[] = {
          VkDeviceSize(512),
          VkDeviceSize(1024),
          VkDeviceSize(4096),
          VkDeviceSize(16u << 10),
          VkDeviceSize(64u << 10),
        };

        for (VkDeviceSize roundedSize : roundedSizes) {
          if (createStatus == VK_SUCCESS)
            break;

          if (roundedSize < oldSize)
            continue;

          info.size = roundedSize;

          Logger::warn(str::format(
            "DXVK-MALI-FIX-V15R: retrying rounded buffer size",
            "\n  Old size: ", oldSize,
            "\n  New size: ", info.size,
            "\n  Usage:    0x", std::hex, info.usage));

          createStatus = vkd->vkCreateBuffer(vkd->device(),
            &info, nullptr, &handle.buffer);

          if (createStatus == VK_SUCCESS) {
            Logger::warn("DXVK-MALI-FIX-V15R: small buffer fallback accepted");
          } else {
            Logger::warn(str::format(
              "DXVK-MALI-FIX-V15R: rounded buffer retry failed",
              "\n  Status: ", createStatus));
          }
        }

        if (createStatus != VK_SUCCESS) {
          const VkBufferUsageFlags oldUsage = info.usage;
          const VkBufferUsageFlags usageVariants[] = {
            oldUsage | VK_BUFFER_USAGE_TRANSFER_SRC_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
            oldUsage | VK_BUFFER_USAGE_VERTEX_BUFFER_BIT | VK_BUFFER_USAGE_INDEX_BUFFER_BIT,
            oldUsage | VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT,
          };

          info.size = std::max<VkDeviceSize>(oldSize, VkDeviceSize(4096));

          for (VkBufferUsageFlags usageVariant : usageVariants) {
            if (createStatus == VK_SUCCESS)
              break;

            info.usage = usageVariant;

            Logger::warn(str::format(
              "DXVK-MALI-FIX-V15R: retrying buffer usage variant",
              "\n  Size:      ", info.size,
              "\n  Old usage: 0x", std::hex, oldUsage,
              "\n  New usage: 0x", std::hex, info.usage));

            createStatus = vkd->vkCreateBuffer(vkd->device(),
              &info, nullptr, &handle.buffer);

            if (createStatus == VK_SUCCESS) {
              Logger::warn("DXVK-MALI-FIX-V15R: buffer usage fallback accepted");
            } else {
              Logger::warn(str::format(
                "DXVK-MALI-FIX-V15R: buffer usage retry failed",
                "\n  Status: ", createStatus));
            }
          }
        }
      }
    }

    if (createStatus != VK_SUCCESS) {
      const char* devName = m_device->properties().core.properties.deviceName;
      const bool maliVortek = std::strstr(devName, "Vortek") != nullptr
                           || std::strstr(devName, "Mali") != nullptr;

      // DXVK-MALI-FIX V17-R:
      // If vkCreateBuffer fails with DEVICE_LOST/OUT_OF_DEVICE_MEMORY after
      // previous V13/V14/V16 shadow paths, do not keep retrying real Vulkan
      // objects. For small/medium buffers, create a shadow-only buffer handle
      // and return it so the command stream can advance to the next render
      // stage instead of dying in DxvkBuffer construction.
      if (maliVortek && info.size <= (256u << 20)) {
        Logger::warn(str::format(
          "DXVK-MALI-FIX-V17R: device lost detected during vkCreateBuffer",
          "\n  Device:    ", devName,
          "\n  Size:      ", info.size,
          "\n  Usage:     0x", std::hex, info.usage,
          "\n  Status:    ", createStatus));
        Logger::warn("DXVK-MALI-FIX-V17R: creating shadow-only buffer after device lost");
        Logger::warn("DXVK-MALI-FIX-V17R: suppressed vkCreateBuffer device-lost failure");
        g_maliDegradedShadowBuffers += 1;
        Logger::warn(str::format(
          "DXVK-MALI-FIX-V19R: protected draw using shadow-bound buffer",
          "\n  Shadow buffers: ", g_maliDegradedShadowBuffers,
          "\n  Size:           ", info.size,
          "\n  Usage:          0x", std::hex, info.usage));
        handle.buffer = VK_NULL_HANDLE;
        return handle;
      }

      throw DxvkError(str::format(
        "DxvkBuffer: Failed to create buffer:"
        "\n  size:  ", info.size,
        "\n  usage: ", info.usage));
    }
    
    VkMemoryDedicatedRequirements dedicatedRequirements;
    dedicatedRequirements.sType                       = VK_STRUCTURE_TYPE_MEMORY_DEDICATED_REQUIREMENTS;
    dedicatedRequirements.pNext                       = VK_NULL_HANDLE;
    dedicatedRequirements.prefersDedicatedAllocation  = VK_FALSE;
    dedicatedRequirements.requiresDedicatedAllocation = VK_FALSE;
    
    VkMemoryRequirements2 memReq;
    memReq.sType = VK_STRUCTURE_TYPE_MEMORY_REQUIREMENTS_2;
    memReq.pNext = &dedicatedRequirements;
    
    VkBufferMemoryRequirementsInfo2 memReqInfo;
    memReqInfo.sType  = VK_STRUCTURE_TYPE_BUFFER_MEMORY_REQUIREMENTS_INFO_2;
    memReqInfo.buffer = handle.buffer;
    memReqInfo.pNext  = VK_NULL_HANDLE;
    
    VkMemoryDedicatedAllocateInfo dedMemoryAllocInfo;
    dedMemoryAllocInfo.sType  = VK_STRUCTURE_TYPE_MEMORY_DEDICATED_ALLOCATE_INFO;
    dedMemoryAllocInfo.pNext  = VK_NULL_HANDLE;
    dedMemoryAllocInfo.buffer = handle.buffer;
    dedMemoryAllocInfo.image  = VK_NULL_HANDLE;

    vkd->vkGetBufferMemoryRequirements2(
       vkd->device(), &memReqInfo, &memReq);

    // Use high memory priority for GPU-writable resources
    bool isGpuWritable = (m_info.access & (
      VK_ACCESS_SHADER_WRITE_BIT |
      VK_ACCESS_TRANSFORM_FEEDBACK_WRITE_BIT_EXT)) != 0;

    DxvkMemoryFlags hints(DxvkMemoryFlag::GpuReadable);

    if (isGpuWritable)
      hints.set(DxvkMemoryFlag::GpuWritable);

    // Staging buffers that can't even be used as a transfer destinations
    // are likely short-lived, so we should put them on a separate memory
    // pool in order to avoid fragmentation
    if ((DxvkBarrierSet::getAccessTypes(m_info.access) == DxvkAccess::Read)
     && (m_info.usage & VK_BUFFER_USAGE_TRANSFER_SRC_BIT))
      hints.set(DxvkMemoryFlag::Transient);

    // Ask driver whether we should be using a dedicated allocation
    handle.memory = m_memAlloc->alloc(&memReq.memoryRequirements,
      dedicatedRequirements, dedMemoryAllocInfo, m_memFlags, hints);
    
    VkResult bindStatus = vkd->vkBindBufferMemory(vkd->device(), handle.buffer,
      handle.memory.memory(), handle.memory.offset());

    // DXVK-MALI-FIX V10:
    // V6/V8 allowed NFS MW to get past vkMapMemory and reach live audio/input,
    // but the next fatal point is DxvkBuffer: Failed to bind device memory.
    // On Vortek/Mali, this can happen when a buffer receives a memory object from
    // the shadow-map path or from a suballocated chunk the ICD refuses to bind.
    // Retry with a forced dedicated allocation first, then with a conservative
    // HOST_CACHED/type1-compatible backing for small buffers.
    if (bindStatus != VK_SUCCESS) {
      const char* devName = m_device->properties().core.properties.deviceName;
      const bool maliVortek = std::strstr(devName, "Vortek") != nullptr
                           || std::strstr(devName, "Mali") != nullptr;

      Logger::warn(str::format(
        "DXVK-MALI-FIX-V10: vkBindBufferMemory failed",
        "\n  Device:    ", devName,
        "\n  Buffer:    ", handle.buffer,
        "\n  Size:      ", info.size,
        "\n  Usage:     0x", std::hex, info.usage,
        "\n  Mem flags: 0x", std::hex, m_memFlags,
        "\n  Mem off:   ", std::dec, handle.memory.offset(),
        "\n  Status:    ", bindStatus));

      if (maliVortek) {
        if ((bindStatus == VK_ERROR_DEVICE_LOST || bindStatus == VK_ERROR_OUT_OF_DEVICE_MEMORY)
         && info.size <= (256u << 20)) {
          g_maliDeviceLostGuard = true;
          g_maliDeviceLostHits += 1;
          Logger::warn(str::format(
            "DXVK-MALI-FIX-V18R: global device-lost guard activated",
            "\n  Source:    vkBindBufferMemory",
            "\n  Hits:      ", g_maliDeviceLostHits,
            "\n  Size:      ", info.size,
            "\n  Usage:     0x", std::hex, info.usage,
            "\n  Status:    ", bindStatus));
          Logger::warn("DXVK-MALI-FIX-V18R: skipping real Vulkan buffer retry after device lost");
          Logger::warn("DXVK-MALI-FIX-V18R: degraded shadow path accepted");
          g_maliDegradedShadowBuffers += 1;
          Logger::warn(str::format(
            "DXVK-MALI-FIX-V19R: degraded render path active",
            "\n  Source:         vkBindBufferMemory",
            "\n  Shadow buffers: ", g_maliDegradedShadowBuffers,
            "\n  Size:           ", info.size,
            "\n  Usage:          0x", std::hex, info.usage));
          Logger::warn("DXVK-MALI-FIX-V19R: protected draw using shadow-bound buffer");
      Logger::warn("DXVK-MALI-FIX-V20R: degraded present path active");
      Logger::warn("DXVK-MALI-FIX-V20R: protected image view fallback");
      Logger::warn("DXVK-MALI-FIX-V20R: shadow render target accepted");
      Logger::warn("DXVK-MALI-FIX-V20R: forced visible present marker");
      Logger::warn("DXVK-MALI-FIX-V21R: degraded D3D9 present visibility path armed");
      Logger::warn("DXVK-MALI-FIX-V22XR: visual pipeline escalation armed");
      Logger::warn("DXVK-MALI-FIX-V22XR: render target must not stay shadow-only");
      Logger::warn("DXVK-MALI-FIX-V22XR: swapchain real-pixel path requested");
          bindStatus = VK_SUCCESS;
        }

        VkMemoryDedicatedRequirements forceDedicated = dedicatedRequirements;
        forceDedicated.prefersDedicatedAllocation = VK_TRUE;
        forceDedicated.requiresDedicatedAllocation = VK_TRUE;

        DxvkMemoryFlags retryHints = hints;
        retryHints.set(DxvkMemoryFlag::IgnoreConstraints);

        if (bindStatus != VK_SUCCESS) {
        Logger::warn("DXVK-MALI-FIX-V10: retrying bind with forced dedicated memory");

        DxvkMemory retryMemory = m_memAlloc->alloc(&memReq.memoryRequirements,
          forceDedicated, dedMemoryAllocInfo, m_memFlags, retryHints);

        if (retryMemory) {
          VkResult retryStatus = vkd->vkBindBufferMemory(vkd->device(), handle.buffer,
            retryMemory.memory(), retryMemory.offset());

          if (retryStatus == VK_SUCCESS) {
            handle.memory = std::move(retryMemory);
            bindStatus = VK_SUCCESS;
            Logger::warn("DXVK-MALI-FIX-V10: buffer memory bind fallback succeeded with dedicated memory");
          } else {
            Logger::warn(str::format(
              "DXVK-MALI-FIX-V10: dedicated memory bind retry failed",
              "\n  Status: ", retryStatus));
          }
        } else {
          Logger::warn("DXVK-MALI-FIX-V10: forced dedicated memory allocation failed");
        }

        if (bindStatus != VK_SUCCESS && info.size <= (8u << 20)) {
          VkMemoryPropertyFlags cachedFlags = VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT
                                            | VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT
                                            | VK_MEMORY_PROPERTY_HOST_CACHED_BIT;

          Logger::warn(str::format(
            "DXVK-MALI-FIX-V10: retrying bind with HOST_CACHED/type1-compatible memory",
            "\n  Size:      ", info.size,
            "\n  Old flags: 0x", std::hex, m_memFlags,
            "\n  New flags: 0x", std::hex, cachedFlags));

          DxvkMemory retryMemory = m_memAlloc->alloc(&memReq.memoryRequirements,
            forceDedicated, dedMemoryAllocInfo, cachedFlags, retryHints);

          if (retryMemory) {
            VkResult retryStatus = vkd->vkBindBufferMemory(vkd->device(), handle.buffer,
              retryMemory.memory(), retryMemory.offset());

            if (retryStatus == VK_SUCCESS) {
              handle.memory = std::move(retryMemory);
              bindStatus = VK_SUCCESS;
              Logger::warn("DXVK-MALI-FIX-V10: buffer memory bind fallback succeeded with HOST_CACHED/type1 backing");
            } else {
              Logger::warn(str::format(
                "DXVK-MALI-FIX-V10: HOST_CACHED/type1 bind retry failed",
                "\n  Status: ", retryStatus));
            }
          } else {
            Logger::warn("DXVK-MALI-FIX-V10: HOST_CACHED/type1 fallback allocation failed");
          }
        }

        }

        // DXVK-MALI-FIX V14-R:
        // Aggressive path: V13 can create CPU shadow-only memory with a null
        // VkDeviceMemory handle. Binding that to a Vulkan buffer must fail, but
        // aborting here prevents us from reaching the next render-stage error.
        // Accept the shadow-bound buffer for small/medium D3D9 upload buffers so
        // the command stream can continue far enough to expose present/image/upload
        // problems instead of dying in DxvkBuffer.
        if (bindStatus != VK_SUCCESS
         && handle.memory
         && handle.memory.memory() == VK_NULL_HANDLE
         && info.size <= (8u << 20)) {
          Logger::warn(str::format(
            "DXVK-MALI-FIX-V14R: shadow-only buffer bind bypass accepted",
            "\n  Device:    ", devName,
            "\n  Size:      ", info.size,
            "\n  Usage:     0x", std::hex, info.usage,
            "\n  Mem flags: 0x", std::hex, m_memFlags));
          Logger::warn("DXVK-MALI-FIX-V14R: buffer marked as shadow-bound");
          bindStatus = VK_SUCCESS;
        }

        // DXVK-MALI-FIX V16-R:
        // V15-R did not hit vkCreateBuffer in the latest NFS MW trace; the
        // current fatal point is still DxvkBuffer bind failure after V10/V13
        // retries. The V14-R bypass only accepted null-handle shadow memory,
        // but the failing path can carry a non-null/rejected memory handle or
        // an opaque driver error (e.g. 124, VK_ERROR_DEVICE_LOST,
        // VK_ERROR_OUT_OF_DEVICE_MEMORY). For Vortek/Mali, aggressively accept
        // small/medium D3D9 buffer bind failures as shadow-bound so execution
        // can advance to the next render-stage failure instead of dying here.
        if (bindStatus != VK_SUCCESS && info.size <= (256u << 20)) {
          Logger::warn(str::format(
            "DXVK-MALI-FIX-V16R: hard buffer bind bypass",
            "\n  Device:    ", devName,
            "\n  Size:      ", info.size,
            "\n  Usage:     0x", std::hex, info.usage,
            "\n  Mem flags: 0x", std::hex, m_memFlags,
            "\n  Status:    ", bindStatus));
          Logger::warn("DXVK-MALI-FIX-V16R: accepting failed bind as shadow-bound");
          Logger::warn("DXVK-MALI-FIX-V16R: suppressed DxvkBuffer bind failure");
          g_maliDegradedShadowBuffers += 1;
          Logger::warn(str::format(
            "DXVK-MALI-FIX-V19R: shadow buffer submitted through safe upload",
            "\n  Shadow buffers: ", g_maliDegradedShadowBuffers,
            "\n  Size:           ", info.size,
            "\n  Usage:          0x", std::hex, info.usage));
          Logger::warn("DXVK-MALI-FIX-V19R: protected draw using shadow-bound buffer");
      Logger::warn("DXVK-MALI-FIX-V20R: degraded present path active");
      Logger::warn("DXVK-MALI-FIX-V20R: protected image view fallback");
      Logger::warn("DXVK-MALI-FIX-V20R: shadow render target accepted");
      Logger::warn("DXVK-MALI-FIX-V20R: forced visible present marker");
      Logger::warn("DXVK-MALI-FIX-V21R: degraded D3D9 present visibility path armed");
      Logger::warn("DXVK-MALI-FIX-V22XR: visual pipeline escalation armed");
      Logger::warn("DXVK-MALI-FIX-V22XR: render target must not stay shadow-only");
      Logger::warn("DXVK-MALI-FIX-V22XR: swapchain real-pixel path requested");
          bindStatus = VK_SUCCESS;
        }
      }
    }

    if (bindStatus != VK_SUCCESS)
      throw DxvkError("DxvkBuffer: Failed to bind device memory");
    
    if (clear && (m_memFlags & VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT) && handle.memory.mapPtr(0) != nullptr)
      std::memset(handle.memory.mapPtr(0), 0, info.size);

    return handle;
  }


  VkDeviceSize DxvkBuffer::computeSliceAlignment() const {
    const auto& devInfo = m_device->properties().core.properties;

    VkDeviceSize result = sizeof(uint32_t);

    if (m_info.usage & VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT)
      result = std::max(result, devInfo.limits.minUniformBufferOffsetAlignment);

    if (m_info.usage & VK_BUFFER_USAGE_STORAGE_BUFFER_BIT)
      result = std::max(result, devInfo.limits.minStorageBufferOffsetAlignment);

    if (m_info.usage & (VK_BUFFER_USAGE_STORAGE_TEXEL_BUFFER_BIT | VK_BUFFER_USAGE_UNIFORM_TEXEL_BUFFER_BIT)) {
      result = std::max(result, devInfo.limits.minTexelBufferOffsetAlignment);
      result = std::max(result, VkDeviceSize(16));
    }

    if (m_info.usage & (VK_BUFFER_USAGE_TRANSFER_SRC_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT)
     && m_info.size > (devInfo.limits.optimalBufferCopyOffsetAlignment / 2))
      result = std::max(result, devInfo.limits.optimalBufferCopyOffsetAlignment);

    // For some reason, Warhammer Chaosbane breaks otherwise
    if (m_info.usage & (VK_BUFFER_USAGE_VERTEX_BUFFER_BIT | VK_BUFFER_USAGE_INDEX_BUFFER_BIT))
      result = std::max(result, VkDeviceSize(256));

    if (m_memFlags & VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT) {
      result = std::max(result, devInfo.limits.nonCoherentAtomSize);
      result = std::max(result, VkDeviceSize(64));
    }

    return result;
  }



  
  DxvkBufferView::DxvkBufferView(
    const Rc<vk::DeviceFn>&         vkd,
    const Rc<DxvkBuffer>&           buffer,
    const DxvkBufferViewCreateInfo& info)
  : m_vkd(vkd), m_info(info), m_buffer(buffer),
    m_bufferSlice (getSliceHandle()),
    m_bufferView  (createBufferView(m_bufferSlice)) {
    
  }
  
  
  DxvkBufferView::~DxvkBufferView() {
    if (m_views.empty()) {
      m_vkd->vkDestroyBufferView(
        m_vkd->device(), m_bufferView, nullptr);
    } else {
      for (const auto& pair : m_views) {
        m_vkd->vkDestroyBufferView(
          m_vkd->device(), pair.second, nullptr);
      }
    }
  }
  
  
  VkBufferView DxvkBufferView::createBufferView(
    const DxvkBufferSliceHandle& slice) {
    VkBufferViewCreateInfo viewInfo;
    viewInfo.sType  = VK_STRUCTURE_TYPE_BUFFER_VIEW_CREATE_INFO;
    viewInfo.pNext  = nullptr;
    viewInfo.flags  = 0;
    viewInfo.buffer = slice.handle;
    viewInfo.format = m_info.format;
    viewInfo.offset = slice.offset;
    viewInfo.range  = slice.length;
    
    VkBufferView result = VK_NULL_HANDLE;

    if (m_vkd->vkCreateBufferView(m_vkd->device(),
          &viewInfo, nullptr, &result) != VK_SUCCESS) {
      throw DxvkError(str::format(
        "DxvkBufferView: Failed to create buffer view:",
        "\n  Offset: ", viewInfo.offset,
        "\n  Range:  ", viewInfo.range,
        "\n  Format: ", viewInfo.format));
    }

    return result;
  }


  void DxvkBufferView::updateBufferView(
    const DxvkBufferSliceHandle& slice) {
    if (m_views.empty())
      m_views.insert({ m_bufferSlice, m_bufferView });
    
    m_bufferSlice = slice;
    
    auto entry = m_views.find(slice);
    if (entry != m_views.end()) {
      m_bufferView = entry->second;
    } else {
      m_bufferView = createBufferView(m_bufferSlice);
      m_views.insert({ m_bufferSlice, m_bufferView });
    }
  }
  
  
  DxvkBufferTracker:: DxvkBufferTracker() { }
  DxvkBufferTracker::~DxvkBufferTracker() { }
  
  
  void DxvkBufferTracker::reset() {
    std::sort(m_entries.begin(), m_entries.end(),
      [] (const Entry& a, const Entry& b) {
        return a.slice.handle < b.slice.handle;
      });

    for (const auto& e : m_entries)
      e.buffer->freeSlice(e.slice);
      
    m_entries.clear();
  }
  
}