DXVK 1.10.3 Mali V7 - Small DEVICE_LOCAL fallback

Objetivo:
- Manter Surface fix da V1.
- Manter explicit-size map da V2.
- Manter exact-size/type1 da V3/V4.
- Manter shadow-map ampliado da V6.
- Corrigir o novo gargalo encontrado na V6: pequenas alocações DEVICE_LOCAL puras falhando, exemplo flags 0x1 / size 1536.

Marcadores esperados no log:
- DXVK-MALI-FIX-V7: small DEVICE_LOCAL fallback
- DXVK-MALI-FIX-V7: accepted small DEVICE_LOCAL allocation with HOST_CACHED/type1 backing
- DXVK-MALI-FIX-V6: shadow-map fallback malloc succeeded

Atenção:
Esta versão ainda é experimental. Ela tenta transformar pequenas alocações DEVICE_LOCAL em um caminho HOST_CACHED/type1 compatível com o fallback shadow da V6. Se passar do erro atual, o próximo alvo deve ser upload real CPU shadow -> GPU para corrigir tela preta/renderização.
