DXVK 1.10.3 Mali V10

Objetivo:
- Mantém fixes V1-V9.
- Novo alvo V10: DxvkBuffer: Failed to bind device memory.
- Quando vkBindBufferMemory falhar no Vortek/Mali, tenta:
  1) memória dedicada forçada;
  2) fallback HOST_CACHED/type1 para buffers pequenos.

Marcadores esperados no log:
- DXVK-MALI-FIX-V10: vkBindBufferMemory failed
- DXVK-MALI-FIX-V10: retrying bind with forced dedicated memory
- DXVK-MALI-FIX-V10: buffer memory bind fallback succeeded with dedicated memory
- DXVK-MALI-FIX-V10: buffer memory bind fallback succeeded with HOST_CACHED/type1 backing

Uso:
- Suba como dxvk_1_10_3_mali_full_builder_v10.zip
- Deixe só esse ZIP na raiz do repo.
- Rode GitHub Actions.
- Pegue artifact/dxvk-1.10.3-mali.tzst e renomeie para dxvk-1.10.3.tzst.
