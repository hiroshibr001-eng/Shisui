DXVK 1.10.3 Mali V5

Foco: opção 1 escolhida pelo usuário.

Mudanças:
- Mantém Surface fix da V1.
- Mantém map explicit-size da V2.
- Mantém teste de exact-size da V3.
- V5 força HOST_CACHED/type1 para Vortek/Mali quando DXVK pedir HOST_VISIBLE|HOST_COHERENT.
- Não volta automaticamente para HOST_COHERENT/type0 no mesmo pedido.

Logs esperados:
DXVK-MALI-FIX-V5: forcing HOST_CACHED/type1 memory path
DXVK-MALI-FIX-V5: trying exact-size HOST_CACHED/type1 allocation
DXVK-MALI-FIX-V5: exact-size HOST_CACHED/type1 allocation succeeded

Se falhar, o próximo caminho é staging/copy, pois type1 também não aceitou vkMapMemory.


DXVK Mali V5: adiciona fallback experimental shadow-map para pequenas alocações quando vkMapMemory falha. Objetivo: testar se passa da criação do device. Pode gerar tela preta/artefatos porque ainda não há cópia GPU real.
