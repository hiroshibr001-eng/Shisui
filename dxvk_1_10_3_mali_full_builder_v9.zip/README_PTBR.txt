DXVK 1.10.3 Mali V9

Inclui os patches anteriores V1-V8 e adiciona fallback para falha em DxvkDescriptorPool.

Novo alvo:
- err: DxvkDescriptorPool: Failed to create descriptor pool

Marcadores esperados no log:
- DXVK-MALI-FIX-V9: trying descriptor pool MaxSets=2048
- DXVK-MALI-FIX-V9: descriptor pool creation failed MaxSets=...
- DXVK-MALI-FIX-V9: descriptor pool fallback succeeded MaxSets=...

Uso:
1. Suba este ZIP na raiz do GitHub como dxvk_1_10_3_mali_full_builder_v9.zip.
2. Deixe só esse ZIP na raiz.
3. Rode o workflow Build DXVK Mali 1.10.3 From ZIP.
4. Pegue artifact/dxvk-1.10.3-mali.tzst.
5. Renomeie para dxvk-1.10.3.tzst.
6. Substitua em app/src/main/assets/dxwrapper/dxvk-1.10.3.tzst.
