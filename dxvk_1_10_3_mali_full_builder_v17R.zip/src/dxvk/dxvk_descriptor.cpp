#include <algorithm>

#include "dxvk_descriptor.h"
#include "dxvk_device.h"

namespace dxvk {
  
  DxvkDescriptorPool::DxvkDescriptorPool(const Rc<vk::DeviceFn>& vkd)
  : m_vkd(vkd) {
    m_pool = VK_NULL_HANDLE;

    auto createPool = [this] (uint32_t MaxSets) {
      std::array<VkDescriptorPoolSize, 9> pools = {{
        { VK_DESCRIPTOR_TYPE_SAMPLER,                std::max(1u, MaxSets * 2) },
        { VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE,          std::max(1u, MaxSets * 3) },
        { VK_DESCRIPTOR_TYPE_STORAGE_IMAGE,          std::max(1u, MaxSets / 8) },
        { VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER,         std::max(1u, MaxSets * 3) },
        { VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,         std::max(1u, MaxSets / 8) },
        { VK_DESCRIPTOR_TYPE_UNIFORM_TEXEL_BUFFER,   std::max(1u, MaxSets * 3) },
        { VK_DESCRIPTOR_TYPE_STORAGE_TEXEL_BUFFER,   std::max(1u, MaxSets / 8) },
        { VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER_DYNAMIC, std::max(1u, MaxSets * 3) },
        { VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER, std::max(1u, MaxSets * 2) } }};

      VkDescriptorPoolCreateInfo info;
      info.sType         = VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO;
      info.pNext         = nullptr;
      info.flags         = 0;
      info.maxSets       = MaxSets;
      info.poolSizeCount = pools.size();
      info.pPoolSizes    = pools.data();

      return m_vkd->vkCreateDescriptorPool(m_vkd->device(), &info, nullptr, &m_pool);
    };

    const std::array<uint32_t, 11> attempts = {{ 2048, 1024, 512, 256, 128, 64, 32, 16, 8, 4, 1 }};

    for (uint32_t maxSets : attempts) {
      if (maxSets <= 16)
        Logger::warn(str::format(
          "DXVK-MALI-FIX-V14R: emergency descriptor pool attempt MaxSets=", maxSets));
      else
        Logger::warn(str::format(
          "DXVK-MALI-FIX-V9: trying descriptor pool MaxSets=", maxSets));

      VkResult vr = createPool(maxSets);
      if (vr == VK_SUCCESS) {
        if (maxSets != 2048)
          Logger::warn(str::format(
            maxSets <= 16 ? "DXVK-MALI-FIX-V14R: emergency descriptor pool succeeded MaxSets=" : "DXVK-MALI-FIX-V9: descriptor pool fallback succeeded MaxSets=", maxSets));
        return;
      }

      Logger::err(str::format(
        "DXVK-MALI-FIX-V9: descriptor pool creation failed MaxSets=", maxSets,
        " VkResult=", vr));
    }

    throw DxvkError("DxvkDescriptorPool: Failed to create descriptor pool");
  }
  
  
  DxvkDescriptorPool::~DxvkDescriptorPool() {
    m_vkd->vkDestroyDescriptorPool(
      m_vkd->device(), m_pool, nullptr);
  }
  
  
  VkDescriptorSet DxvkDescriptorPool::alloc(VkDescriptorSetLayout layout) {
    VkDescriptorSetAllocateInfo info;
    info.sType              = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO;
    info.pNext              = nullptr;
    info.descriptorPool     = m_pool;
    info.descriptorSetCount = 1;
    info.pSetLayouts        = &layout;
    
    VkDescriptorSet set = VK_NULL_HANDLE;
    if (m_vkd->vkAllocateDescriptorSets(m_vkd->device(), &info, &set) != VK_SUCCESS)
      return VK_NULL_HANDLE;
    return set;
  }
  
  
  void DxvkDescriptorPool::reset() {
    m_vkd->vkResetDescriptorPool(
      m_vkd->device(), m_pool, 0);
  }




  DxvkDescriptorPoolTracker::DxvkDescriptorPoolTracker(DxvkDevice* device)
  : m_device(device) {

  }


  DxvkDescriptorPoolTracker::~DxvkDescriptorPoolTracker() {

  }


  void DxvkDescriptorPoolTracker::trackDescriptorPool(Rc<DxvkDescriptorPool> pool) {
    m_pools.push_back(std::move(pool));
  }

  
  void DxvkDescriptorPoolTracker::reset() {
    for (const auto& pool : m_pools) {
      pool->reset();
      m_device->recycleDescriptorPool(pool);
    }

    m_pools.clear();
  }
  
}